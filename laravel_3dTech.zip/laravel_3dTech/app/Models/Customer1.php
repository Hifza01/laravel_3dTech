<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer1 extends Model
{
    use HasFactory;

    protected $table = 'customers_1';

    protected $fillable = ['customer_name', 'customer_code', 'region_code'];

    public function tasks()
    {
        return $this->hasMany(Task::class, 'customer_1_id');
    }

}
