<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class UpdateTasksCustomer1ForeignKey extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('tasks', function (Blueprint $table) {
            $table->dropForeign(['customer_1_id']); // Drop the existing foreign key

            $table->foreign('customer_1_id')
                ->references('id')
                ->on('customers_1')
                ->onDelete('set null'); // Add the new foreign key with ON DELETE SET NULL
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('tasks', function (Blueprint $table) {
            $table->dropForeign(['customer_1_id']); // Drop the modified foreign key

            $table->foreign('customer_1_id')
                ->references('id')
                ->on('customers_1'); // Revert to the original foreign key
        });
    }
}
