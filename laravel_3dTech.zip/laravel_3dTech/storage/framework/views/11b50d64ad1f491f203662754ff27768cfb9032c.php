

<?php $__env->startSection('content'); ?>
<div class="container-card">
    <div class="card-profile">
        <div class="card-profile-body">
            <h5 class="card-profile-title">Edit Perusahaan</h5>
            <div class="card-profile-text">
                <form action="<?php echo e(route('update-perusahaan', $company->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-3 d-flex align-items-center">
                        <label for="company_name" class="card-profile-label">Nama Perusahaan</label>
                        <input type="text" class="form-control flex-grow-1" id="company_name" name="company_name" value="<?php echo e($company->company_name); ?>" required>
                    </div> 
                    <div class="mb-3 d-flex align-items-center">
                        <label for="cid" class="card-profile-label">CID</label>
                        <input type="text" class="form-control flex-grow-1" id="cid" name="cid" value="<?php echo e($company->cid); ?>" required>
                    </div> 
                    <div class="profile-footer text-end">
                        <a href="<?php echo e(route('tambah')); ?>" class="btn btn-danger me-2">Batal</a>
                        <button type="submit" class="btn btn-primary">Edit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_3dTech\resources\views/edit-perusahaan.blade.php ENDPATH**/ ?>