<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    use HasFactory;

    public function teknisi()
    {
        return $this->belongsTo(User::class, 'teknisi_id');
    }

    public function comments()
    {
        return $this->hasMany(Comment::class);
    }

    public function company() {
        return $this->belongsTo(Company::class, 'company_id');
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function customer()
    {
        return $this->belongsTo(Customer1::class, 'customer_1_id');
    }

    public function customer2()
    {
        return $this->belongsTo(Customer2::class, 'customer_2_id');
    }
}
