<div class="modal fade" id="addItemModal" tabindex="-1" aria-labelledby="addItemModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addItemModalLabel">Tambah Tugas!</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="addItemForm" action="<?php echo e(route('AddTask')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                    <div class="mb-3 d-flex align-items-center">
                        <label for="name" class="form-label me-3">Nama Teknisi</label>
                        <select class="form-select flex-grow-1" id="name" name="name" required>
                            <option value="">Pilih Teknisi</option>
                            <?php $__currentLoopData = $teknisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tech->id); ?>"><?php echo e($tech->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3 d-flex align-items-center">
                        <label for="job_types" class="form-label me-3">Jenis Pekerjaan</label>
                        <select class="form-select flex-grow-1" id="job_types" name="job_types" required>
                            <option value="">Pilih Jenis Pekerjaan</option>
                            <option value="Internal">Internal</option>
                            <option value="External">External</option>
                        </select>
                    </div>

                    <div class="mb-3 d-flex align-items-center" id="company-container" style="display: none;">
                        <label for="company" class="form-label me-3">Perusahaan</label>
                        <select class="form-select flex-grow-1" id="drawer" onclick="changedrawer()" name="company" required>
                            <option value="">Pilih Perusahaan</option>                            
                            <option value="3DTech">3D Tech</option>                            
                            <option value="Ngx">Ngx</option>                            
                        </select>
                    </div>

                    <div class="mb-3 d-flex align-items-center" id="1">
                        <label for="customer_1" class="form-label me-3">Pilih Customer</label>
                        <select class="form-select flex-grow-1" id="customer_1" name="customer_1">
                            <option value="">Pilih Customer</option>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->customer_name); ?> - <?php echo e($customer->customer_code); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3 d-flex align-items-center" id="2">
                        <label for="customer_2" class="form-label me-3">Pilih Ngx</label>
                        <select class="form-select flex-grow-1" id="customer_2" name="customer_2">
                            <option value="">Pilih Ngx</option>
                            <?php $__currentLoopData = $customers2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($customer2->id); ?>"><?php echo e($customer2->customer_name); ?> - <?php echo e($customer2->customer_code); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3 d-flex align-items-center">
                        <label for="category" class="form-label me-3">Kategori</label>
                        <select class="form-select flex-grow-1" id="category" name="category" required>
                            <option value="">Pilih Kategori</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->category_name); ?>"><?php echo e($category->category_code); ?> - <?php echo e($category->category_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3 d-flex align-items-center">
                        <label for="content" class="form-label me-3">Isi Aduan</label>
                        <textarea class="form-control flex-grow-1" id="content" name="content" rows="3" required></textarea>
                    </div>

                    <div class="mb-3 d-flex align-items-center">
                        <label for="due" class="form-label me-3">Tenggat Waktu</label>
                        <input type="datetime-local" class="form-control flex-grow-1" id="due" name="due" required>
                    </div>

                    <div class="mb-3 d-flex align-items-center">
                        <label for="color" class="form-label me-3">Status</label>
                        <select class="form-select flex-grow-1" id="color" name="color" required>
                            <option value="">Pilih Status</option>
                            <option value="merah">Isi Aduan Mendesak</option>
                            <option value="kuning">Isi Aduan tidak terlalu Mendesak</option>
                            <option value="hijau">Isi Aduan Aman, tidak Mendesak</option>
                        </select>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    function changedrawer(){
        var status=document.getElementById("drawer").value;
        switch (status){
            case "3DTech":
                document.getElementById("1").style.visibility="visible";
                document.getElementById("2").style.visibility="hidden";
                break;
            case "Ngx":
                document.getElementById("1").style.visibility="hidden";
                document.getElementById("2").style.visibility="visible";
                break;
            default:
                document.getElementById("1").style.visibility="visible";
                document.getElementById("2").style.visibility="visible";
        }
    }
</script>
<?php /**PATH C:\xampp\htdocs\laravel_3dTech\resources\views/partials/modal_tambah.blade.php ENDPATH**/ ?>