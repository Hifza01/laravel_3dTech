@extends('layouts.app')

@section('content')
<div class="container-card">
    <div class="card-profile">
        <div class="card-profile-body">
            <h5 class="card-profile-title">Tambah Costumer</h5>            
            <div class="card-profile-text">
                <form action="{{ route('AddCustomer1') }}" method="POST">
                    @csrf
                    <div class="mb-3 d-flex align-items-center">
                        <label for="customer_name" class="card-profile-label">Nama Costumer</label>
                        <input type="text" value="{{ old('customer_name') }}" class="form-control flex-grow-1" id="customer_name" name="customer_name" required>
                        @error('customer_name')
                            <span class="text-danger ms-2">{{ $message }}</span>
                        @enderror
                    </div> 
                    <div class="mb-3 d-flex align-items-center">
                        <label for="customer_code" class="card-profile-label">CID</label>
                        <input type="text" value="{{ old('customer_code') }}" class="form-control flex-grow-1" id="customer_code" name="customer_code" required>
                        @error('customer_code')
                            <span class="text-danger ms-2">{{ $message }}</span>
                        @enderror
                    </div> 
                    <div class="mb-3 d-flex align-items-center">
                        <label for="region_code" class="card-profile-label">Kode Wilayah</label>
                        <select class="form-control flex-grow-1" id="region_code" name="region_code" required>
                            <option value="">Pilih Kode Wilayah</option>
                            @foreach ($region_codes as $code => $name)
                                <option value="{{ $code }}" {{ old('region_code') == $code ? 'selected' : '' }}>
                                    {{ $code }} - {{ $name }}
                                </option> 
                            @endforeach
                        </select>
                        @error('region_code')
                            <span class="text-danger ms-2">{{ $message }}</span>
                        @enderror
                    </div>

                    <div class="profile-footer text-end">
                        <a href="{{ route('tambah') }}" class="btn btn-danger me-2">Batal</a>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
