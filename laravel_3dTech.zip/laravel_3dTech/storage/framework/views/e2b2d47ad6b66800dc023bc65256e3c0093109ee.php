

<?php $__env->startSection('content'); ?>
<div class="container-card">
    <div class="card-profile">
        <div class="card-profile-body">
            <h5 class="card-profile-title">Edit Profil</h5>
            <div class="card-profile-text">
                <form action="<?php echo e(route('EditUser')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                    <div class="mb-3 d-flex align-items-center">
                        <label for="name" class="card-profile-label">Nama</label>
                        <input type="text" value="<?php echo e($user->name); ?>" class="form-control flex-grow-1" id="name" name="name">
                    </div> 
                    <div class="mb-3 d-flex align-items-center">
                        <label for="email" class="card-profile-label">Email</label>
                        <input type="email" value="<?php echo e($user->email); ?>" class="form-control flex-grow-1" id="email" name="email">
                    </div> 
                    <div class="mb-3 d-flex align-items-center">
                        <label for="password" class="card-profile-label">Kata Sandi</label>
                        <input type="password" class="form-control flex-grow-1" id="password" name="password" required>
                    </div> 
                    <div class="mb-3 d-flex align-items-center">
                        <label for="password_confirmation" class="card-profile-label">Konfirmasi Kata Sandi</label>
                        <input type="password" class="form-control flex-grow-1" id="password_confirmation" name="password_confirmation" required>
                    </div>
                    <div class="profile-footer text-end">
                        <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-danger me-2">Batal</a>
                        <button type="submit" class="btn btn-primary">Edit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_3dTech\resources\views/edit-user.blade.php ENDPATH**/ ?>