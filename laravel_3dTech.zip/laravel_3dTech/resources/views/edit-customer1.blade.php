@extends('layouts.app')

@section('content')
<div class="container-card">
    <div class="card-profile">
        <div class="card-profile-body">
            <h5 class="card-profile-title">Edit Customer</h5>
            <div class="card-profile-text">
                <form action="{{ route('update-customer1', $customer->id) }}" method="POST">
                    @csrf
                    @method('PUT')
                    <div class="mb-3 d-flex align-items-center">
                        <label for="customer_name" class="card-profile-label">Nama Customer</label>
                        <input type="text" name="customer_name" id="customer_name" class="form-control flex-grow-1" value="{{ old('customer_name', $customer->customer_name) }}">
                    </div>
                    <div class="mb-3 d-flex align-items-center">
                        <label for="customer_code" class="card-profile-label">CID</label>
                        <input type="text" name="customer_code" id="customer_code" class="form-control flex-grow-1" value="{{ old('customer_code', $customer->customer_code) }}">
                    </div>
                    <div class="profile-footer text-end">
                        <a href="{{ route('tambah') }}" class="btn btn-danger me-2">Batal</a>
                        <button type="submit" class="btn btn-primary">Edit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
