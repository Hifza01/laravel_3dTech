<aside id="sidebar" class="sidebar-toggle">
    <div class="logo">
        <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo" />
    </div>
    <ul class="sidebar-nav p-0">                
        <ul class="menu sidebar-nav p-0">
            <li><a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">Beranda</a></li>
            <li><a href="<?php echo e(route('laporan')); ?>" class="<?php echo e(request()->routeIs('laporan') ? 'active' : ''); ?>">Laporan</a></li>
            <?php if(Auth::check() && Auth::user()->level === 'admin'): ?>
                <li><a href="<?php echo e(route('pengajuan')); ?>" class="<?php echo e(request()->routeIs('pengajuan') ? 'active' : ''); ?>">Pengajuan</a></li>
            <?php endif; ?>
        </ul>
    </ul>
</aside><?php /**PATH C:\xampp\htdocs\laravel_3dTech\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>