

<?php $__env->startSection('content'); ?>
<div class="container-card">
    <div class="card-profile">
        <div class="card-profile-body">
            <h5 class="card-profile-title">Tambah Kategori</h5>            
            <div class="card-profile-text">
                <form action="<?php echo e(route('AddCategory')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3 d-flex align-items-center">
                        <label for="category_name" class="card-profile-label">Kategori</label>
                        <input type="text" value="<?php echo e(old('category_name')); ?>" class="form-control flex-grow-1" id="category_name" name="category_name" required>
                        <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger ms-2"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>                     
                    <div class="profile-footer text-end">
                        <a href="<?php echo e(route('tambah')); ?>" class="btn btn-danger me-2">Batal</a>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_3dTech\resources\views/tambah-kategori.blade.php ENDPATH**/ ?>