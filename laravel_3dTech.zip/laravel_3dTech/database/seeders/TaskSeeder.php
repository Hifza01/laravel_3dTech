<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;


class TaskSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('tasks')->where('category', 'FO Cut')->update(['no_category' => '01']);
        DB::table('tasks')->where('category', 'Ping Intermitern')->update(['no_category' => '02']);
        DB::table('tasks')->where('category', 'Speed tidak sesuai Kontrak')->update(['no_category' => '03']);
        DB::table('tasks')->where('category', 'Gangguan Routing')->update(['no_category' => '04']);
        DB::table('tasks')->where('category', 'Gangguan Perangkat')->update(['no_category' => '05']);
        DB::table('tasks')->where('category', 'Gangguan Radio')->update(['no_category' => '06']);
        DB::table('tasks')->where('category', 'Pekerjaan External')->update(['no_category' => '07']);
        DB::table('tasks')->where('category', 'Aktivasi FTTH')->update(['no_category' => '08']);
        DB::table('tasks')->where('category', 'Maintenance')->update(['no_category' => '09']);
    }
}
