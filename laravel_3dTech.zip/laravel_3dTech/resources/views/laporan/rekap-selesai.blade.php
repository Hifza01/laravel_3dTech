<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Tugas yang Selesai</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f9f9f9;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        th, td {
            border: 1px solid #000;
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #e0e0e0;
        }
    </style>
</head>
<body>
    <h1>Rekap Tugas yang Selesai {{ $bulan != 0 ? \Carbon\Carbon::createFromFormat('m', $bulan)->translatedFormat('F') : 'Tahun' }} {{ $tahun }}</h1>
    <table>
        <thead>
            <tr>
                <th>Nama Teknisi</th>
                <th>Kode Tugas</th>
                <th>Perusahaan</th>
                <th>Isi Aduan</th>
                <th>Tenggat Waktu</th>
                <th>Waktu Selesai</th>
            </tr>
        </thead>
        <tbody>
            @foreach($data as $task)
                <tr>
                    <td>{{ $task->teknisi->name }}</td>
                    <td>{{ $task->no_category }}</td>
                    <td>
                        {{ $task->company->company_name ?? '' }} {{ $task->company->cid ?? '-' }}
                    </td>
                    <td>{{ $task->content }}</td>
                    <td>{{ \Carbon\Carbon::parse($task->due)->format('d F Y') }}</td>
                    <td>{{ \Carbon\Carbon::parse($task->updated_at)->format('d F Y, H:i') }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
