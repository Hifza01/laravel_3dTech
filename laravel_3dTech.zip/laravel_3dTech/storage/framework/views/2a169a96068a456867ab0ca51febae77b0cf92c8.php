<nav class="navbar navbar-expand">
    <button class="toggler-btn" type="button">
        <i class="lni lni-menu"></i>
    </button>
    <div class="search-container">
    </div>
    <div class="nav-icons">
        <a href="#" data-bs-toggle="modal" data-bs-target="#notificationModal">
            <img src="<?php echo e(asset('img/icon2.png')); ?>" alt="Bell Icon" class="icon">
        </a>
        <div class="dropdown">
            <a href="#" class="d-flex align-items-center text-decoration-none" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                <img src="<?php echo e(asset('img/icon1.png')); ?>" alt="Profile Icon" class="icon">
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                <?php if(Auth::check()): ?>
                    <li>
                        <h6 class="dropdown-header">Welcome, <?php echo e(Auth::user()->name); ?></h6>
                    </li>
                <?php endif; ?>
                <li>
                    <a class="dropdown-item" href="/edit/<?php echo e(Auth::user()->id); ?>">
                        <img src="<?php echo e(asset('img/edit-icon.png')); ?>" alt="Edit Icon" class="me-2" style="width: 16px; height: 16px;">
                        Edit Profil
                    </a>
                </li>
                <?php if(Auth::check() && Auth::user()->level === 'admin'): ?>
                <li>
                    <a class="dropdown-item" href="<?php echo e(route('tambah')); ?>">
                        <img src="<?php echo e(asset('img/add-account-icon.png')); ?>" alt="Add Account Icon" class="me-2" style="width: 16px; height: 16px;">
                        Data Akun & Perusahaan
                    </a>
                </li>
                <?php endif; ?>
                <li>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>

                    <a class="dropdown-item" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <img src="<?php echo e(asset('img/logout-icon.png')); ?>" alt="Logout Icon" class="me-2" style="width: 16px; height: 16px;">
                        Keluar
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\laravel_3dTech\resources\views/partials/navbar.blade.php ENDPATH**/ ?>