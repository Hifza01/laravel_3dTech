

<?php $__env->startSection('content'); ?>
<div class="container mt-5" style="overflow-x:auto; min-height: 100vh">
    <table class="table table-bordered table-hover text-center">
        <thead class="table-primary">
            <tr>
                <th scope="col">Nama Teknisi</th>
                <th scope="col">Jenis Pekerjaan</th>
                <th scope="col">Perusahaan</th>
                <th scope="col">Customer</th>
                <th scope="col">Ngx</th>
                <th scope="col">Kategori Tugas</th>
                <th scope="col">Tenggat Waktu</th>
                <th scope="col">Isi Aduan</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($task->teknisi->name); ?></td>
                <td><?php echo e($task->job_types); ?></td>
                <td><?php echo e($task->company); ?></td>
                <td><?php echo e($task->customer ? $task->customer->customer_code : '-'); ?></td>
                <td><?php echo e($task->customer2 ? $task->customer2->customer_code : '-'); ?></td>
                <td><?php echo e($task->no_category); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($task->due)->format('d-m-Y H:i')); ?></td>
                <td><?php echo e($task->content); ?></td>
                <td>
                <form action="<?php echo e(route('task.approve', $task->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-primary" type="submit">Terima</button>
                    </form>
                    <form action="<?php echo e(route('task.reject', $task->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-danger" type="submit">Tolak</button>
                    </form>                    
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_3dTech\resources\views/pengajuan.blade.php ENDPATH**/ ?>