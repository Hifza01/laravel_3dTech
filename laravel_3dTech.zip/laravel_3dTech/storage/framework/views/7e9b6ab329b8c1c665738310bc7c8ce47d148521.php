<div class="kanban-column">
    <div class="kanban-header">
        <h5><?php echo e($title); ?></h5>
        <?php if(isset($addButton)): ?>
            <a href="#" class="btn-add" data-bs-toggle="modal" data-bs-target="#addItemModal">+</a>
        <?php endif; ?>
    </div>
    <div class="kanban-body">
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card card-home
                <?php if($task->color === 'merah'): ?> bg-merah 
                <?php elseif($task->color === 'kuning'): ?> bg-kuning 
                <?php elseif($task->color === 'hijau'): ?> bg-hijau 
                <?php endif; ?>">
                <div class="card-body card-body-home">
                    <div style="display: flex; justify-content: space-between; width: 100%;">
                        <h5 class="card-title"><?php echo e($task->teknisi->name); ?></h5>
                        <p class="card-title"><?php echo e($task->no_ticket); ?>-<?php echo e($task->no_category); ?></p>
                    </div>
                    <h6 class="card-subtitle text-body-secondary"><?php echo e($task->category); ?></h6>
                    <p class="card-text card-text-home" style="margin-top: 6px;"><?php echo e($task->content); ?></p>
                    <div class="task-actions">
                        <form action="<?php echo e(route('task.update_status', $task->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <input type="hidden" name="status" value="<?php echo e($statusUpdate); ?>">
                            <button type="submit" class="btn btn-card"><?php echo e($buttonText); ?></button>
                        </form>
                        <p class="card-link card-link-home">Due Date: <?php echo e($task->due); ?></p>
                    </div>
                    <button type="button" class="btn btn-comment d-flex justify-content-between align-items-center" data-bs-toggle="modal" data-bs-target="#commentModal<?php echo e($task->id); ?>">
                        <span>Comment</span>
                        <img src="<?php echo e(asset('img/send-icon.png')); ?>" alt="Send Icon">
                    </button>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel_3dTech\resources\views/partials/kanban_column.blade.php ENDPATH**/ ?>