

<?php $__env->startSection('content'); ?>
<div class="container container-home mt-5" style="min-height: 100vh">
    <div class="row">
        <div class="col-md-auto">
            <div class="kanban-column">
                <div class="kanban-header">
                    <h5>To Do</h5>
                    <a href="#" class="btn-add" data-bs-toggle="modal" data-bs-target="#addItemModal">+</a>
                </div>
                <div class="kanban-body">
                    <?php $__currentLoopData = $toDoTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card card-home
                            <?php if($task->color === 'merah'): ?> bg-merah 
                            <?php elseif($task->color === 'kuning'): ?> bg-kuning 
                            <?php elseif($task->color === 'hijau'): ?> bg-hijau 
                            <?php endif; ?>">
                            <div class="card-body card-body-home">
                                <div style="display: flex; justify-content: space-between; width: 100%;">
                                    <h5 class="card-title"><?php echo e($task->teknisi->name); ?></h5>
                                    <p class="card-title"><?php echo e($task->no_category); ?>-<?php echo e($task->no_ticket); ?></p>
                                </div>
                                <h6 class="card-subtitle text-body-secondary"><?php echo e($task->job_types); ?>-<?php echo e($task->company); ?></h6>
                                <h6 class="card-subtitle text-body-secondary">
                                    <?php if($task->customer): ?>
                                        <?php echo e($task->customer->customer_code); ?> <?php echo e($task->customer->region_code); ?>

                                    <?php else: ?>
                                        
                                    <?php endif; ?>
                                    <?php if($task->customer2): ?>
                                        <?php echo e($task->customer2->customer_code); ?> <?php echo e($task->customer2->region_code); ?>

                                    <?php else: ?>
                                        
                                    <?php endif; ?>
                                </h6>
                                <p class="card-text card-text-home" style="width: 100%; text-align: left; margin-top: 6px;"><?php echo e($task->content); ?></p>
                                <div class="task-actions">
                                    <form action="<?php echo e(route('task.update_status', $task->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <input type="hidden" name="status" value="in_progress">
                                        <button type="submit" class="btn btn-card">Do It</button>
                                    </form>
                                    <p class="card-link card-link-home">
                                        Due Date: <?php echo e(\Carbon\Carbon::parse($task->due)->format('d-m-Y H:i')); ?>

                                    </p>   
                                </div> 
                                <button type="button" class="btn btn-comment d-flex justify-content-between align-items-center" data-bs-toggle="modal" data-bs-target="#commentModal<?php echo e($task->id); ?>">
                                    <span>Comment</span>
                                    <img src="<?php echo e(asset('img/send-icon.png')); ?>" alt="Send Icon">
                                </button>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="col-md-auto">
            <div class="kanban-column">
                <div class="kanban-header">
                    <h5>In Progress</h5>
                </div>
                <div class="kanban-body">
                    <?php $__currentLoopData = $inProgressTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($task->is_approved && $task->status === 'in_progress'): ?>
                            <div class="card card-home
                                <?php if($task->color === 'merah'): ?> bg-merah 
                                <?php elseif($task->color === 'kuning'): ?> bg-kuning 
                                <?php elseif($task->color === 'hijau'): ?> bg-hijau 
                                <?php endif; ?>">
                                <div class="card-body card-body-home">
                                    <div style="display: flex; justify-content: space-between; width: 100%;">
                                        <h5 class="card-title"><?php echo e($task->teknisi->name); ?></h5>
                                        <p class="card-title"><?php echo e($task->no_category); ?>-<?php echo e($task->no_ticket); ?></p>
                                    </div>
                                    <h6 class="card-subtitle text-body-secondary"><?php echo e($task->job_types); ?></h6>
                                    <h6 class="card-subtitle text-body-secondary">
                                        <?php if($task->customer): ?>
                                            <?php echo e($task->customer->customer_code); ?> <?php echo e($task->customer->region_code); ?>

                                        <?php else: ?>
                                            
                                        <?php endif; ?>
                                        <?php if($task->customer2): ?>
                                            <?php echo e($task->customer2->customer_code); ?> <?php echo e($task->customer2->region_code); ?>

                                        <?php else: ?>
                                            
                                        <?php endif; ?>
                                    </h6>
                                    <p class="card-text card-text-home" style="width: 100%; text-align: left; margin-top: 6px;"><?php echo e($task->content); ?></p>
                                    <div class="task-actions">
                                        <form action="<?php echo e(route('task.update_status', $task->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <input type="hidden" name="status" value="done">
                                            <button type="submit" class="btn btn-card">Done</button>
                                        </form>
                                        <p class="card-link card-link-home">
                                            Due Date: <?php echo e(\Carbon\Carbon::parse($task->due)->format('d-m-Y H:i')); ?>

                                        </p>  
                                    </div>
                                    <button type="button" class="btn btn-comment d-flex justify-content-between align-items-center" data-bs-toggle="modal" data-bs-target="#commentModal<?php echo e($task->id); ?>">
                                        <span>Comment</span>
                                        <img src="<?php echo e(asset('img/send-icon.png')); ?>" alt="Send Icon">
                                    </button>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="col-md-auto">
            <div class="kanban-column">
                <div class="kanban-header">
                    <h5>Done</h5>
                    <p style="font-size: 10px">(<?php echo e(\Carbon\Carbon::now()->translatedFormat('F, Y')); ?>)</p>
                </div>
                <div class="kanban-body">
                    <?php $__currentLoopData = $doneTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($task->is_approved && $task->status === 'done'): ?>
                            <div class="card card-home
                                <?php if($task->color === 'merah'): ?> bg-merah 
                                <?php elseif($task->color === 'kuning'): ?> bg-kuning 
                                <?php elseif($task->color === 'hijau'): ?> bg-hijau 
                                <?php endif; ?>">
                                <div class="card-body card-body-home">
                                    <div style="display: flex; justify-content: space-between; width: 100%;">
                                        <h5 class="card-title"><?php echo e($task->teknisi->name); ?></h5>
                                        <p class="card-title"><?php echo e($task->no_category); ?>-<?php echo e($task->no_ticket); ?></p>
                                    </div>
                                    <h6 class="card-subtitle text-body-secondary"><?php echo e($task->job_types); ?></h6>
                                    <h6 class="card-subtitle text-body-secondary">
                                        <?php if($task->customer): ?>
                                            <?php echo e($task->customer->customer_code); ?> <?php echo e($task->customer->region_code); ?>

                                        <?php else: ?>
                                            
                                        <?php endif; ?>
                                        <?php if($task->customer2): ?>
                                            <?php echo e($task->customer2->customer_code); ?> <?php echo e($task->customer2->region_code); ?>

                                        <?php else: ?>
                                            
                                        <?php endif; ?>
                                    </h6>
                                    <p class="card-text card-text-home" style="width: 100%; text-align: left; margin-top: 6px;"><?php echo e($task->content); ?></p>
                                    <p class="card-attempt card-attempt-home" style="width: 100%; text-align: right;">Finish Date: <?php echo e($task->updated_at); ?></p>
                                    <button type="button" class="btn btn-comment d-flex justify-content-between align-items-center" data-bs-toggle="modal" data-bs-target="#commentModal<?php echo e($task->id); ?>">
                                        <span>Comment</span>
                                        <img src="<?php echo e(asset('img/send-icon.png')); ?>" alt="Send Icon">
                                    </button>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="col-md-auto">
            <div class="kanban-column">
                <div class="kanban-header">
                    <h5>Backlog</h5>
                </div>
                <div class="kanban-body">
                    <?php $__currentLoopData = $overdueTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card card-home
                            <?php if($task->color === 'merah'): ?> bg-merah 
                            <?php elseif($task->color === 'kuning'): ?> bg-kuning 
                            <?php elseif($task->color === 'hijau'): ?> bg-hijau 
                            <?php endif; ?>">
                            <div class="card-body card-body-home">
                                <div style="display: flex; justify-content: space-between; width: 100%;">
                                    <h5 class="card-title"><?php echo e($task->teknisi->name); ?></h5>
                                    <p class="card-title"><?php echo e($task->no_category); ?>-<?php echo e($task->no_ticket); ?></p>
                                </div>
                                <h6 class="card-subtitle text-body-secondary"><?php echo e($task->job_types); ?>-<?php echo e($task->company); ?></h6>
                                <h6 class="card-subtitle text-body-secondary">
                                    <?php if($task->customer): ?>
                                        <?php echo e($task->customer->customer_code); ?> <?php echo e($task->customer->region_code); ?>

                                    <?php else: ?>
                                        
                                    <?php endif; ?>
                                    <?php if($task->customer2): ?>
                                        <?php echo e($task->customer2->customer_code); ?> <?php echo e($task->customer2->region_code); ?>

                                    <?php else: ?>
                                        
                                    <?php endif; ?>
                                </h6>
                                <p class="card-text card-text-home" style="width: 100%; text-align: left; margin-top: 6px;"><?php echo e($task->content); ?></p>
                                <div class="task-actions">
                                    <form action="<?php echo e(route('task.update_status', $task->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <input type="hidden" name="status" value="in_progress">
                                        <button type="submit" class="btn btn-card">Do It</button>
                                    </form>
                                    <p class="card-link card-link-home">
                                        Due Date: <?php echo e(\Carbon\Carbon::parse($task->due)->format('d-m-Y H:i')); ?>

                                    </p>  
                                </div>   
                                <button type="button" class="btn btn-comment d-flex justify-content-between align-items-center" data-bs-toggle="modal" data-bs-target="#commentModal<?php echo e($task->id); ?>">
                                    <span>Comment</span>
                                    <img src="<?php echo e(asset('img/send-icon.png')); ?>" alt="Send Icon">
                                </button>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('partials.modal_tambah', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.modal_komen', ['tasks' => $toDoTasks], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.modal_komen', ['tasks' => $inProgressTasks], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.modal_komen', ['tasks' => $doneTasks], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.modal_komen', ['tasks' => $overdueTasks], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_3dTech\resources\views/dashboard.blade.php ENDPATH**/ ?>