<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="commentModal<?php echo e($task->id); ?>" tabindex="-1" aria-labelledby="commentModalLabel<?php echo e($task->id); ?>" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="commentModalLabel<?php echo e($task->id); ?>">
                        Komentar untuk <?php echo e($task->teknisi->name ?? 'Teknisi Tidak Ditemukan'); ?> - <?php echo e($task->no_ticket); ?> | <?php echo e($task->no_category ?? 'Kategori Tidak Ditemukan'); ?>-<?php echo e($task->category ?? 'Kategori Tidak Ditemukan'); ?>

                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="comments-section mb-3">
                        <?php if($task->comments->isEmpty()): ?>
                            <p>Tidak ada komentar.</p>
                        <?php else: ?>
                            <?php $__currentLoopData = $task->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="comment mb-2">
                                    <strong><?php echo e($comment->user->name); ?></strong> <em><?php echo e($comment->created_at->diffForHumans()); ?></em>
                                    <p><?php echo e($comment->comment); ?></p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <form action="<?php echo e(route('comments.store', $task->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="comment<?php echo e($task->id); ?>" class="form-label">Tambah Komentar</label>
                            <textarea class="form-control" id="comment<?php echo e($task->id); ?>" name="comment" rows="3" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Kirim</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\laravel_3dTech\resources\views/partials/modal_komen.blade.php ENDPATH**/ ?>