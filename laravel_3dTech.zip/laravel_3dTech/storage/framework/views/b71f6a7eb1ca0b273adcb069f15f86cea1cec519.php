

<?php $__env->startSection('content'); ?>
<div class="container-add mt-5">
    <div class="card-add mb-4">
        <div class="card-header-add d-flex justify-content-between">
            Daftar Akun
            <a href="<?php echo e(route('tambah-akun')); ?>" class="btn btn-primary">Tambah akun</a>
        </div>
        <div class="card-body-add">
            <table class="table table-bordered table-hover text-center">
                <thead class="table-primary">
                    <tr>
                        <th>Nama</th>
                        <th>Role</th>
                        <th>Email</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $teknisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->level); ?></td>
                        <td><?php echo e($user->email); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card-add">
        <div class="card-header-add d-flex justify-content-between">
            Daftar Customer
            <a href="<?php echo e(route('tambah-customer1')); ?>" class="btn btn-primary">Tambah Customer</a>
        </div>
        <div class="card-body-add">
            <table class="table table-bordered table-hover text-center">
                <thead class="table-primary">
                    <tr>
                        <th>Nama Customer</th>
                        <th>CID</th>
                        <th>Kode Wilayah</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($customer->customer_name); ?></td>
                            <td><?php echo e($customer->customer_code); ?></td>
                            <td><?php echo e($customer->region_code); ?></td>
                            <td>
                                <a href="<?php echo e(route('edit-customer1', $customer->id)); ?>" class="btn btn-warning btn-sm">Edit</a> 
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card-add">
        <div class="card-header-add d-flex justify-content-between">
            Daftar Ngx
            <a href="<?php echo e(route('tambah-customer2')); ?>" class="btn btn-primary">Tambah Ngx</a>
        </div>
        <div class="card-body-add">
            <table class="table table-bordered table-hover text-center">
                <thead class="table-primary">
                    <tr>
                        <th>Nama Ngx</th>
                        <th>CID</th>
                        <th>Kode Wilayah</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $customers2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($customer2->customer_name); ?></td>
                            <td><?php echo e($customer2->customer_code); ?></td>
                            <td><?php echo e($customer2->region_code); ?></td>
                            <td>
                                <a href="<?php echo e(route('edit-customer2', $customer2->id)); ?>" class="btn btn-warning btn-sm">Edit</a>  
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card-add">
        <div class="card-header-add d-flex justify-content-between">
            Daftar Kategori
            <a href="<?php echo e(route('tambah-kategori')); ?>" class="btn btn-primary">Tambah Kategori</a>
        </div>
        <div class="card-body-add">
            <table class="table table-bordered table-hover text-center">
                <thead class="table-primary">
                    <tr>
                        <th>Nama Kategori</th>
                        <th>Kode Kategori</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($category->category_name); ?></td>
                        <td><?php echo e($category->category_code); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_3dTech\resources\views/tambah.blade.php ENDPATH**/ ?>