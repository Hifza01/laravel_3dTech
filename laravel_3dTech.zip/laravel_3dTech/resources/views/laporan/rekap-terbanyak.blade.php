<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Tugas yang Paling Banyak Diajukan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f9f9f9;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        th, td {
            border: 1px solid #000;
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #e0e0e0;
        }
    </style>
</head>
<body>
    <h1>Rekap Tugas yang Paling Banyak Diajukan {{ $bulan != 0 ? \Carbon\Carbon::createFromFormat('m', $bulan)->translatedFormat('F') : 'Tahun' }} {{ $tahun }}</h1>
    <table>
        <thead>
            <tr>
                <th>Kode Tugas</th>
                <th>Kategori Tugas</th>
                <th>Total Pengajuan</th>
            </tr>
        </thead>
        <tbody>
            @foreach($data as $task)
                <tr>
                    <td>{{ $task->no_category }}</td>
                    <td>{{ $task->category }}</td>
                    <td>{{ $task->total }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
