<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="shortcut icon" href="<?php echo e(asset('img/Logo.png')); ?>">
        <title><?php echo $__env->yieldContent('title', '3d Tech'); ?></title>
        <link href="https://fonts.googleapis.com/css2?family=Inknut+Antiqua:wght@400;500;700&display=swap" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet" />
        <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/layout.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/laporan.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/profil.css')); ?>">
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <?php echo $__env->yieldContent('head'); ?>
    </head>
    <body>
        <div class="d-flex">
            <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="main">
                <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('partials.modal_notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('partials.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="content">
                    <?php echo $__env->yieldContent('content'); ?>            
                </div>
                <footer class="footer mt-5 py-3">
                    <div class="container">
                        <span class="text-muted">© 2024 3dTech. All rights reserved.</span>
                    </div>
                </footer>      
            </div>        
        </div>    
        <?php echo $__env->yieldContent('scripts'); ?>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo e(asset('js/script.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel_3dTech\resources\views/layouts/app.blade.php ENDPATH**/ ?>