@extends('layouts.app')

@section('content')
<div class="container-add mt-5">
    <div class="card-add mb-4">
        <div class="card-header-add d-flex justify-content-between">
            Daftar Akun
            <a href="{{ route('tambah-akun') }}" class="btn btn-primary">Tambah akun</a>
        </div>
        <div class="card-body-add">
            <table class="table table-bordered table-hover text-center">
                <thead class="table-primary">
                    <tr>
                        <th>Nama</th>
                        <th>Role</th>
                        <th>Email</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($teknisi as $user)
                    <tr>
                        <td>{{ $user->name }}</td>
                        <td>{{ $user->level }}</td>
                        <td>{{ $user->email }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    <div class="card-add">
        <div class="card-header-add d-flex justify-content-between">
            Daftar Customer
            <a href="{{ route('tambah-customer1') }}" class="btn btn-primary">Tambah Customer</a>
        </div>
        <div class="card-body-add">
            <table class="table table-bordered table-hover text-center">
                <thead class="table-primary">
                    <tr>
                        <th>Nama Customer</th>
                        <th>CID</th>
                        <th>Kode Wilayah</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($customers as $customer)
                        <tr>
                            <td>{{ $customer->customer_name }}</td>
                            <td>{{ $customer->customer_code }}</td>
                            <td>{{ $customer->region_code }}</td>
                            <td>
                                <a href="{{ route('edit-customer1', $customer->id) }}" class="btn btn-warning btn-sm">Edit</a> 
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    <div class="card-add">
        <div class="card-header-add d-flex justify-content-between">
            Daftar Ngx
            <a href="{{ route('tambah-customer2') }}" class="btn btn-primary">Tambah Ngx</a>
        </div>
        <div class="card-body-add">
            <table class="table table-bordered table-hover text-center">
                <thead class="table-primary">
                    <tr>
                        <th>Nama Ngx</th>
                        <th>CID</th>
                        <th>Kode Wilayah</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($customers2 as $customer2)
                        <tr>
                            <td>{{ $customer2->customer_name }}</td>
                            <td>{{ $customer2->customer_code }}</td>
                            <td>{{ $customer2->region_code }}</td>
                            <td>
                                <a href="{{ route('edit-customer2', $customer2->id) }}" class="btn btn-warning btn-sm">Edit</a>  
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    <div class="card-add">
        <div class="card-header-add d-flex justify-content-between">
            Daftar Kategori
            <a href="{{ route('tambah-kategori') }}" class="btn btn-primary">Tambah Kategori</a>
        </div>
        <div class="card-body-add">
            <table class="table table-bordered table-hover text-center">
                <thead class="table-primary">
                    <tr>
                        <th>Nama Kategori</th>
                        <th>Kode Kategori</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($categories as $category)
                    <tr>
                        <td>{{ $category->category_name }}</td>
                        <td>{{ $category->category_code }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
