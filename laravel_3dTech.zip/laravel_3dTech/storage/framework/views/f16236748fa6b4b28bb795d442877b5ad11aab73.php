

<?php $__env->startSection('content'); ?>
<div class="container mt-4" style="height: 80vh">
    <h3>Tambah Tugas!</h3>
    <form id="addItemForm" action="<?php echo e(route('AddTask')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3 d-flex align-items-center">
            <label for="name" class="card-profile-label">Nama Teknisi</label>
            <select class="form-control flex-grow-1" id="name" name="name" required>
                <option value="">Pilih Teknisi</option>
                <?php $__currentLoopData = $teknisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($tech->id); ?>"><?php echo e($tech->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3 d-flex align-items-center">
            <label for="job_types" class="card-profile-label">Jenis Pekerjaan</label>
            <select class="form-control flex-grow-1" id="job_types" name="job_types" required>
                <option value="">Pilih Jenis Pekerjaan</option>
                <option value="Internal">Internal</option>
                <option value="External">External</option>
            </select>
        </div>

        <div class="mb-3 d-flex align-items-center" id="company-container" style="display: none;">
            <label for="company" class="card-profile-label">Perusahaan</label>
            <select class="form-control flex-grow-1" id="drawer" onclick="changedrawer()" name="company" required>
                <option value="">Pilih Perusahaan</option>
                <option value="3DTech">3D Tech</option>
                <option value="Ngx">Ngx</option>
            </select>
        </div>

        <div class="mb-3 d-flex align-items-center" id="1">
            <label for="customer_1" class="card-profile-label">Pilih Customer</label>
            <select class="form-control flex-grow-1" id="customer_1" name="customer_1">
                <option value="">Pilih Customer</option>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->customer_name); ?> - <?php echo e($customer->customer_code); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3 d-flex align-items-center" id="2">
            <label for="customer_2" class="card-profile-label">Pilih Ngx</label>
            <select class="form-control flex-grow-1" id="customer_2" name="customer_2">
                <option value="">Pilih Ngx</option>
                <?php $__currentLoopData = $customers2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($customer2->id); ?>"><?php echo e($customer2->customer_name); ?> - <?php echo e($customer2->customer_code); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3 d-flex align-items-center">
            <label for="category" class="card-profile-label">Kategori</label>
            <select class="form-control flex-grow-1" id="category" name="category" required>
                <option value="">Pilih Kategori</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->category_name); ?>"><?php echo e($category->category_code); ?> - <?php echo e($category->category_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3 d-flex align-items-center">
            <label for="content" class="card-profile-label">Isi Aduan</label>
            <textarea class="form-control flex-grow-1" id="content" name="content" rows="3" required></textarea>
        </div>

        <div class="mb-3 d-flex align-items-center">
            <label for="due" class="card-profile-label">Tenggat Waktu</label>
            <input type="datetime-local" class="form-control flex-grow-1" id="due" name="due" required>
        </div>

        <div class="mb-3 d-flex align-items-center">
            <label for="color" class="card-profile-label">Status</label>
            <select class="form-control flex-grow-1" id="color" name="color" required>
                <option value="">Pilih Status</option>
                <option value="merah">Isi Aduan Mendesak</option>
                <option value="kuning">Isi Aduan tidak terlalu Mendesak</option>
                <option value="hijau">Isi Aduan Aman, tidak Mendesak</option>
            </select>
        </div>

        <div class="profile-footer text-end">
            <a href="#" class="btn btn-danger">Batal</a>
            <button type="submit" class="btn btn-primary">Tambah</button>
        </div>
    </form>
</div>

<script>
    function changedrawer(){
        var status = document.getElementById("drawer").value;
        switch (status) {
            case "3DTech":
                document.getElementById("1").style.visibility = "visible";
                document.getElementById("2").style.visibility = "hidden";
                break;
            case "Ngx":
                document.getElementById("1").style.visibility = "hidden";
                document.getElementById("2").style.visibility = "visible";
                break;
            default:
                document.getElementById("1").style.visibility = "visible";
                document.getElementById("2").style.visibility = "visible";
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_3dTech\resources\views/tambah-tugas.blade.php ENDPATH**/ ?>