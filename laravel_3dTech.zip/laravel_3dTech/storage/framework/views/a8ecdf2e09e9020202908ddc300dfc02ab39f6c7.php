

<?php $__env->startSection('content'); ?>
<div class="container-card">
    <div class="card-profile">
        <div class="card-profile-body">
            <h5 class="card-profile-title">Tambah Akun</h5>            
            <div class="card-profile-text">
                <form action="<?php echo e(route('AddUser')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3 d-flex align-items-center">
                        <label for="name" class="card-profile-label">Nama Akun</label>
                        <input type="text" value="<?php echo e(old('name')); ?>" class="form-control flex-grow-1" id="name" name="name" required>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger ms-2"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div> 
                    <div class="mb-3 d-flex align-items-center">
                        <label for="email" class="card-profile-label">Email</label>
                        <input type="email" value="<?php echo e(old('email')); ?>" class="form-control flex-grow-1" id="email" name="email" required>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger ms-2"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div> 
                    <div class="mb-3 d-flex align-items-center">
                        <label for="password" class="card-profile-label">Kata Sandi</label>
                        <input type="password" class="form-control flex-grow-1" id="password" name="password" required>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger ms-2"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div> 
                    <div class="mb-3 d-flex align-items-center">
                        <label for="password_confirmation" class="card-profile-label">Konfirmasi Kata Sandi</label>
                        <input type="password" class="form-control flex-grow-1" id="password_confirmation" name="password_confirmation" required>
                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger ms-2"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div> 
                    <div class="mb-3 d-flex align-items-center">
                        <label for="level" class="card-profile-label" style="margin-right: 10px;">Role</label>
                        <select class="form-select flex-grow-1" id="level" name="level" required>
                            <option value="" disabled selected>Pilih Role</option>
                            <option value="admin" <?php echo e(old('level') == 'admin' ? 'selected' : ''); ?>>Admin</option>
                            <option value="teknisi" <?php echo e(old('level') == 'teknisi' ? 'selected' : ''); ?>>Teknisi</option>
                        </select>
                        <?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger ms-2"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="profile-footer text-end">
                        <a href="<?php echo e(route('tambah')); ?>" class="btn btn-danger me-2">Batal</a>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_3dTech\resources\views/tambah-akun.blade.php ENDPATH**/ ?>