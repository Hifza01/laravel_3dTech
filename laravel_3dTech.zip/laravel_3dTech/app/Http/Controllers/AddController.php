<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Customer1;
use App\Models\Customer2;
use App\Models\Category;
use App\Models\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\File;

class AddController extends Controller
{
    public function LoadAdd() {
        $teknisi = User::where('level', 'teknisi')->get(); 
        $customers = Customer1::all(); 
        $customers2 = Customer2::all();
        $categories = Category::all();
    
        $notifications = Notification::latest()->get();
    
        return view('tambah', compact('teknisi', 'notifications', 'customers', 'customers2', 'categories')); 
    }
    
    private function getRegionCodes()
    {
        $filePath = storage_path('app/regions.json');
        if (File::exists($filePath)) {
            $regions = json_decode(File::get($filePath), true);
        } else {
            $regions = [];
        }

        $region_codes = [];
        foreach ($regions as $province => $data) {
            foreach ($data['regions'] as $region) {
                $region_codes[$region['code']] = $region['name'];
            }
        }

        return $region_codes;
    }

    public function LoadAddUser() {
        $teknisi = User::where('level', 'teknisi')->get();

        $notifications = Notification::latest()->get();

        return view('tambah-akun', compact('teknisi', 'notifications')); 
    }

    public function AddUser(Request $request) {
        $request->validate([
            'name' => 'required|string',
            'level' => 'required|string',
            'email' => 'required|email|unique:users',            
            'password' => 'required|confirmed|min:5|max:8',
        ]);
        try {
            $user = new User;
            $user->name = $request->name;
            $user->level = $request->level;
            $user->email = $request->email;
            $user->password = Hash::make($request->password);
            $user->save();

            return redirect('/tambah')->with('success','Akun Berhasil Ditambah');
        } catch (\Exception $e) {
            return redirect('/tambah-akun')->with('fail','Akun Gagal Ditambah');
        }  
    }

    public function deleteUser($id)
    {
        try {
            $user = User::findOrFail($id);
            $user->delete();

            return redirect()->route('tambah')->with('success', 'Akun berhasil dihapus');
        } catch (\Exception $e) {
            return redirect()->route('tambah')->with('fail', 'Akun gagal dihapus');
        }
    }
    
    public function LoadAddCustomer1() {
        $teknisi = User::where('level', 'teknisi')->get();
        $notifications = Notification::latest()->get();

        $filePath = storage_path('app/regions.json'); 
        if (File::exists($filePath)) {
            $regions = json_decode(File::get($filePath), true);
        } else {
            $regions = []; 
        }

        $region_codes = [];
            foreach ($regions as $province => $data) {
                foreach ($data['regions'] as $region) {
                    $region_codes[$region['code']] = $region['name'];
                }
            }

        return view('tambah-customer1', compact('teknisi', 'notifications', 'regions', 'region_codes')); 
    }

    public function AddCustomer1(Request $request)
    {
        $request->validate([
            'customer_name' => 'required|string|max:255',
            'customer_code' => 'required|string|max:10|unique:customers_1',
            'region_code' => 'required|string|max:10|in:' . implode(',', array_keys($this->getRegionCodes())),
        ]);

        try {
            $customer = new Customer1;
            $customer->customer_name = $request->customer_name;
            $customer->customer_code = $request->customer_code;
            $customer->region_code = $request->region_code;
            $customer->save();

            return redirect()->route('tambah')->with('success', 'Perusahaan berhasil ditambahkan');
        } catch (\Exception $e) {
            return redirect()->route('tambah-customer1')->with('fail', 'Perusahaan gagal ditambahkan');
        }
    }

    public function editCustomer1($id)
    {
        $notifications = Notification::latest()->get();

        try {
            $customer = Customer1::findOrFail($id);
            return view('edit-customer1', compact('customer', 'notifications'));
        } catch (\Exception $e) {
            return redirect()->route('tambah')->with('fail', 'Perusahaan tidak ditemukan');
        }
    }

    public function updateCustomer1(Request $request, $id)
    {
        $request->validate([
            'customer_name' => 'required|string|max:255',
            'customer_code' => 'required|string|max:10|unique:customers_1,customer_code,' . $id,
        ]);

        try {
            $customer = Customer1::findOrFail($id);
            $customer->customer_name = $request->customer_name;
            $customer->customer_code = $request->customer_code;
            $customer->save();

            return redirect()->route('tambah')->with('success', 'Customer successfully updated');
        } catch (\Exception $e) {
            return redirect()->route('edit-customer1', $id)->with('fail', 'Failed to update customer: ' . $e->getMessage());
        }
    }

    public function deleteCustomer1($id)
    {
        $customer = Customer1::findOrFail($id);
    
        if ($customer->tasks()->exists()) {
            return redirect()->route('tambah')
                             ->with('fail', 'Cannot delete customer. It is associated with tasks.');
        }
    
        $customer->delete();
    
        return redirect()->route('tambah')->with('success', 'Customer deleted successfully.');
    }

    public function LoadAddCustomer2() {
        $teknisi = User::where('level', 'teknisi')->get();
        $notifications = Notification::latest()->get();

        $filePath = storage_path('app/regions.json'); 
        if (File::exists($filePath)) {
            $regions = json_decode(File::get($filePath), true);
        } else {
            $regions = []; 
        }

        $region_codes = [];
            foreach ($regions as $province => $data) {
                foreach ($data['regions'] as $region) {
                    $region_codes[$region['code']] = $region['name'];
                }
            }

        return view('tambah-customer2', compact('teknisi', 'notifications', 'regions', 'region_codes')); 
    }

    public function AddCustomer2(Request $request)
    {
        $request->validate([
            'customer_name' => 'required|string|max:255',
            'customer_code' => 'required|string|max:10|unique:customers_1',
            'region_code' => 'required|string|max:10|in:' . implode(',', array_keys($this->getRegionCodes())),
        ]);

        try {            
            $customer = new Customer2;
            $customer->customer_name = $request->customer_name;
            $customer->customer_code = $request->customer_code;
            $customer->region_code = $request->region_code;
            $customer->save();

            return redirect()->route('tambah')->with('success', 'Perusahaan berhasil ditambahkan');
        } catch (\Exception $e) {
            return redirect()->route('tambah-customer2')->with('fail', 'Perusahaan gagal ditambahkan');
        }
    }

    public function editCustomer2($id)
    {
        $notifications = Notification::latest()->get();

        try {
            $customer2 = Customer2::findOrFail($id); 
            return view('edit-customer2', compact('customer2', 'notifications')); 
        } catch (\Exception $e) {
            return redirect()->route('tambah')->with('fail', 'Customer not found');
        }
    }

    public function updateCustomer2(Request $request, $id)
    {
        $request->validate([
            'customer_name' => 'required|string|max:255',
            'customer_code' => 'required|string|max:10|unique:customers_2,customer_code,' . $id, 
        ]);

        try {
            $customer2 = Customer2::findOrFail($id); 
            $customer2->customer_name = $request->customer_name;
            $customer2->customer_code = $request->customer_code;
            $customer2->save();

            return redirect()->route('tambah')->with('success', 'Customer successfully updated');
        } catch (\Exception $e) {
            return redirect()->route('edit-customer2', $id)->with('fail', 'Failed to update customer: ' . $e->getMessage());
        }
    }

    public function deleteCustomer2($id)
    {
        try {
            $customer2 = Customer2::findOrFail($id);
            $customer2->delete();

            return redirect()->route('tambah')->with('success', 'Perusahaan berhasil dihapus');
        } catch (\Exception $e) {
            return redirect()->route('tambah')->with('fail', 'Perusahaan gagal dihapus');
        }
    }

    public function LoadAddCategory() {
        $teknisi = User::where('level', 'teknisi')->get();

        $notifications = Notification::latest()->get();

        return view('tambah-kategori', compact('teknisi', 'notifications')); 
    }

    public function AddCategory(Request $request)
    {
        $request->validate([
            'category_name' => 'required|string|max:255|unique:categories,category_name', 
        ]);

        try {
            $categoryCount = Category::count(); 
            $categoryCode = str_pad($categoryCount + 1, 2, '0', STR_PAD_LEFT); 

            $category = new Category;
            $category->category_name = $request->category_name;
            $category->category_code = $categoryCode; 
            $category->save();

            return redirect()->route('tambah')->with('success', 'Kategori berhasil ditambahkan');
        } catch (\Exception $e) {
            return redirect()->route('tambah-kategori')->with('fail', 'Kategori gagal ditambahkan');
        }
    }


}
