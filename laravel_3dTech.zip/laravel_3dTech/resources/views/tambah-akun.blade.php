@extends('layouts.app')

@section('content')
<div class="container-card">
    <div class="card-profile">
        <div class="card-profile-body">
            <h5 class="card-profile-title">Tambah Akun</h5>            
            <div class="card-profile-text">
                <form action="{{ route('AddUser') }}" method="POST">
                    @csrf
                    <div class="mb-3 d-flex align-items-center">
                        <label for="name" class="card-profile-label">Nama Akun</label>
                        <input type="text" value="{{ old('name') }}" class="form-control flex-grow-1" id="name" name="name" required>
                        @error('name')
                            <span class="text-danger ms-2">{{ $message }}</span>
                        @enderror
                    </div> 
                    <div class="mb-3 d-flex align-items-center">
                        <label for="email" class="card-profile-label">Email</label>
                        <input type="email" value="{{ old('email') }}" class="form-control flex-grow-1" id="email" name="email" required>
                        @error('email')
                            <span class="text-danger ms-2">{{ $message }}</span>
                        @enderror
                    </div> 
                    <div class="mb-3 d-flex align-items-center">
                        <label for="password" class="card-profile-label">Kata Sandi</label>
                        <input type="password" class="form-control flex-grow-1" id="password" name="password" required>
                        @error('password')
                            <span class="text-danger ms-2">{{ $message }}</span>
                        @enderror
                    </div> 
                    <div class="mb-3 d-flex align-items-center">
                        <label for="password_confirmation" class="card-profile-label">Konfirmasi Kata Sandi</label>
                        <input type="password" class="form-control flex-grow-1" id="password_confirmation" name="password_confirmation" required>
                        @error('password_confirmation')
                            <span class="text-danger ms-2">{{ $message }}</span>
                        @enderror
                    </div> 
                    <div class="mb-3 d-flex align-items-center">
                        <label for="level" class="card-profile-label" style="margin-right: 10px;">Role</label>
                        <select class="form-select flex-grow-1" id="level" name="level" required>
                            <option value="" disabled selected>Pilih Role</option>
                            <option value="admin" {{ old('level') == 'admin' ? 'selected' : '' }}>Admin</option>
                            <option value="teknisi" {{ old('level') == 'teknisi' ? 'selected' : '' }}>Teknisi</option>
                        </select>
                        @error('level')
                            <span class="text-danger ms-2">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="profile-footer text-end">
                        <a href="{{ route('tambah') }}" class="btn btn-danger me-2">Batal</a>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
