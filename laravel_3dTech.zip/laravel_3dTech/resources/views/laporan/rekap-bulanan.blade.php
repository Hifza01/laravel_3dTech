<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Laporan Bulanan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f9f9f9;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        th, td {
            border: 1px solid #000;
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #e0e0e0;
        }
    </style>
</head>
<body>
    <h1>Rekap Laporan {{ $bulan != 0 ? \Carbon\Carbon::createFromFormat('m', $bulan)->translatedFormat('F') : 'Tahun' }} {{ $tahun }}</h1>
    <table>
        <thead>
            <tr>
                <th>Nama Teknisi</th>
                <th>Jenis Pekerjaan</th>
                <th>Kode Tiket</th>
                <th>Kode Tugas</th>
                <th>Perusahaan</th>
                <th>Tanggal</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            @foreach($data as $task)
                <tr>
                    <td>{{ $task->teknisi->name }}</td>
                    <td>{{ $task->job_types }}</td>
                    <td>{{ $task->no_ticket }}</td>
                    <td>{{ $task->no_category }}</td>
                    <td>
                        {{ $task->company->company_name ?? '' }} {{ $task->company->cid ?? '-' }}
                    </td>
                    <td>{{ \Carbon\Carbon::parse($task->due)->translatedFormat('d F Y') }}</td>
                    <td>{{ $task->status }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
