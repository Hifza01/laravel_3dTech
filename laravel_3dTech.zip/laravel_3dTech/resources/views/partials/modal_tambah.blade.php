<div class="modal fade" id="addItemModal" tabindex="-1" aria-labelledby="addItemModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addItemModalLabel">Tambah Tugas!</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="addItemForm" action="{{ route('AddTask') }}" method="POST">
                @csrf
                    <div class="mb-3 d-flex align-items-center">
                        <label for="name" class="form-label me-3">Nama Teknisi</label>
                        <select class="form-select flex-grow-1" id="name" name="name" required>
                            <option value="">Pilih Teknisi</option>
                            @foreach($teknisi as $tech)
                                <option value="{{ $tech->id }}">{{ $tech->name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="mb-3 d-flex align-items-center">
                        <label for="job_types" class="form-label me-3">Jenis Pekerjaan</label>
                        <select class="form-select flex-grow-1" id="job_types" name="job_types" required>
                            <option value="">Pilih Jenis Pekerjaan</option>
                            <option value="Internal">Internal</option>
                            <option value="External">External</option>
                        </select>
                    </div>

                    <div class="mb-3 d-flex align-items-center" id="company-container" style="display: none;">
                        <label for="company" class="form-label me-3">Perusahaan</label>
                        <select class="form-select flex-grow-1" id="drawer" onclick="changedrawer()" name="company" required>
                            <option value="">Pilih Perusahaan</option>                            
                            <option value="3DTech">3D Tech</option>                            
                            <option value="Ngx">Ngx</option>                            
                        </select>
                    </div>

                    <div class="mb-3 d-flex align-items-center" id="1">
                        <label for="customer_1" class="form-label me-3">Pilih Customer</label>
                        <select class="form-select flex-grow-1" id="customer_1" name="customer_1">
                            <option value="">Pilih Customer</option>
                            @foreach($customers as $customer)
                                <option value="{{ $customer->id }}">{{ $customer->customer_name }} - {{ $customer->customer_code }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="mb-3 d-flex align-items-center" id="2">
                        <label for="customer_2" class="form-label me-3">Pilih Ngx</label>
                        <select class="form-select flex-grow-1" id="customer_2" name="customer_2">
                            <option value="">Pilih Ngx</option>
                            @foreach($customers2 as $customer2)
                                <option value="{{ $customer2->id }}">{{ $customer2->customer_name }} - {{ $customer2->customer_code }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="mb-3 d-flex align-items-center">
                        <label for="category" class="form-label me-3">Kategori</label>
                        <select class="form-select flex-grow-1" id="category" name="category" required>
                            <option value="">Pilih Kategori</option>
                            @foreach($categories as $category)
                                <option value="{{ $category->category_name }}">{{ $category->category_code }} - {{ $category->category_name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="mb-3 d-flex align-items-center">
                        <label for="content" class="form-label me-3">Isi Aduan</label>
                        <textarea class="form-control flex-grow-1" id="content" name="content" rows="3" required></textarea>
                    </div>

                    <div class="mb-3 d-flex align-items-center">
                        <label for="due" class="form-label me-3">Tenggat Waktu</label>
                        <input type="datetime-local" class="form-control flex-grow-1" id="due" name="due" required>
                    </div>

                    <div class="mb-3 d-flex align-items-center">
                        <label for="color" class="form-label me-3">Status</label>
                        <select class="form-select flex-grow-1" id="color" name="color" required>
                            <option value="">Pilih Status</option>
                            <option value="merah">Isi Aduan Mendesak</option>
                            <option value="kuning">Isi Aduan tidak terlalu Mendesak</option>
                            <option value="hijau">Isi Aduan Aman, tidak Mendesak</option>
                        </select>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    function changedrawer(){
        var status=document.getElementById("drawer").value;
        switch (status){
            case "3DTech":
                document.getElementById("1").style.visibility="visible";
                document.getElementById("2").style.visibility="hidden";
                break;
            case "Ngx":
                document.getElementById("1").style.visibility="hidden";
                document.getElementById("2").style.visibility="visible";
                break;
            default:
                document.getElementById("1").style.visibility="visible";
                document.getElementById("2").style.visibility="visible";
        }
    }
</script>
