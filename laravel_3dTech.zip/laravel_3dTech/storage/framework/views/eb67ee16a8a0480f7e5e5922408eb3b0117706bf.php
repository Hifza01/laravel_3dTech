<?php if(session('success')): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Berhasil',
            text: "<?php echo e(session('success')); ?>",
            timer: 2000,
            showConfirmButton: false,
            toast: true,
            position: 'center'
        });
    </script>
<?php endif; ?>

<?php if(session('fail')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Gagal',
            text: "<?php echo e(session('fail')); ?>",
            timer: 3000,
            showConfirmButton: false,
            toast: true,
            position: 'center'
        });
    </script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel_3dTech\resources\views/partials/notif.blade.php ENDPATH**/ ?>