

<?php $__env->startSection('content'); ?>
<div class="container-card">
    <div class="card-profile">
        <div class="card-profile-body">
            <h5 class="card-profile-title">Tambah Costumer</h5>            
            <div class="card-profile-text">
                <form action="<?php echo e(route('AddCustomer1')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3 d-flex align-items-center">
                        <label for="customer_name" class="card-profile-label">Nama Costumer</label>
                        <input type="text" value="<?php echo e(old('customer_name')); ?>" class="form-control flex-grow-1" id="customer_name" name="customer_name" required>
                        <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger ms-2"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div> 
                    <div class="mb-3 d-flex align-items-center">
                        <label for="customer_code" class="card-profile-label">CID</label>
                        <input type="text" value="<?php echo e(old('customer_code')); ?>" class="form-control flex-grow-1" id="customer_code" name="customer_code" required>
                        <?php $__errorArgs = ['customer_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger ms-2"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div> 
                    <div class="mb-3 d-flex align-items-center">
                        <label for="region_code" class="card-profile-label">Kode Wilayah</label>
                        <select class="form-control flex-grow-1" id="region_code" name="region_code" required>
                            <option value="">Pilih Kode Wilayah</option>
                            <?php $__currentLoopData = $region_codes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($code); ?>" <?php echo e(old('region_code') == $code ? 'selected' : ''); ?>>
                                    <?php echo e($code); ?> - <?php echo e($name); ?>

                                </option> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['region_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger ms-2"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="profile-footer text-end">
                        <a href="<?php echo e(route('tambah')); ?>" class="btn btn-danger me-2">Batal</a>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_3dTech\resources\views/tambah-customer1.blade.php ENDPATH**/ ?>