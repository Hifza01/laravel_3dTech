

<?php $__env->startSection('content'); ?>
<div class="container-laporan" style="min-height: 100vh; padding: 30px;">
    <div class="row g-4">
        <?php
            $statuses = [
                ['title' => 'To do', 'count' => $toDoCount, 'color' => '#f39c12'],
                ['title' => 'In progress', 'count' => $inProgressCount, 'color' => '#2980b9'],
                ['title' => 'Done', 'count' => $doneCount, 'color' => '#27ae60'],
                ['title' => 'Backlog', 'count' => $backlogCount, 'color' => '#c0392b']
            ];
        ?>

        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-3">
            <div class="card card-laporan" style="border-left: 8px solid <?php echo e($status['color']); ?>;">
                <div class="card-body card-body-laporan">
                    <h5 class="card-title card-title-laporan"><?php echo e($status['title']); ?></h5>
                    <h1 class="card-text card-text-laporan"><?php echo e($status['count']); ?></h1>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="row text-center" style="margin-top: 50px;">
        <div class="col-lg-6 mb-5">
            <h3 style="font-size: 24px;">Peringkat Teknisi <?php echo e(\Carbon\Carbon::now()->translatedFormat('F Y')); ?></h3>
            <table class="table table-bordered table-hover text-center">
                <thead class="table-primary">
                    <tr>
                        <th>Peringkat</th>
                        <th>Nama Teknisi</th>
                        <th>Jumlah Tugas Selesai</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $teknisiRanking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($tech->name); ?></td>
                            <td><?php echo e($tech->tasks_count); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <?php if(Auth::check() && Auth::user()->level === 'admin'): ?>
        <div class="col-lg-6">
            <div class="card card-pdf">
                <div class="card-body">
                    <h5 class="card-title" style="margin-bottom: 10px;">Download PDF</h5>
                    <form action="<?php echo e(route('download.pdf')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <select name="jenis_laporan" class="form-select" required>
                                <option value="" disabled selected>Pilih jenis laporan</option>
                                <option value="1">Rekap Tugas yang Selesai</option>
                                <option value="2">Rekap Tugas yang Paling Banyak Diajukan</option>
                                <option value="3">Rekap Laporan Bulanan & Tahunan</option>
                                <option value="4">Rekap Peringkat Teknisi</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <select name="bulan" class="form-select" required>
                                <option value="" disabled selected>Pilih bulan</option>
                                <option value="0">Semua Bulan</option>
                                <?php for($i = 1; $i <= 12; $i++): ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e(DateTime::createFromFormat('!m', $i)->format('F')); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <select name="tahun" class="form-select" required>
                                <option value="" disabled selected>Pilih tahun</option>
                                <option value="2024">2024</option>
                                <option value="2025">2025</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Unduh</button>
                    </form>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_3dTech\resources\views/laporan.blade.php ENDPATH**/ ?>