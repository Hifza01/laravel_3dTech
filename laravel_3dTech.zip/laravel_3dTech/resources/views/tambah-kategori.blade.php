@extends('layouts.app')

@section('content')
<div class="container-card">
    <div class="card-profile">
        <div class="card-profile-body">
            <h5 class="card-profile-title">Tambah Kategori</h5>            
            <div class="card-profile-text">
                <form action="{{ route('AddCategory') }}" method="POST">
                    @csrf
                    <div class="mb-3 d-flex align-items-center">
                        <label for="category_name" class="card-profile-label">Kategori</label>
                        <input type="text" value="{{ old('category_name') }}" class="form-control flex-grow-1" id="category_name" name="category_name" required>
                        @error('category_name')
                            <span class="text-danger ms-2">{{ $message }}</span>
                        @enderror
                    </div>                     
                    <div class="profile-footer text-end">
                        <a href="{{ route('tambah') }}" class="btn btn-danger me-2">Batal</a>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
