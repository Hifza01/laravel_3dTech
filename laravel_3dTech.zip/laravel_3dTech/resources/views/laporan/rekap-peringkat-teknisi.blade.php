<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Peringkat Teknisi</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f9f9f9;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        th, td {
            border: 1px solid #000;
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #e0e0e0;
        }
    </style>
</head>
<body>
    <h1>Rekap Peringkat Teknisi Bulan {{ $bulan != 0 ? \Carbon\Carbon::createFromFormat('m', $bulan)->translatedFormat('F') : 'Tahun' }} {{ $tahun }}</h1>    
    <table>
        <thead>
            <tr>
                <th>Peringkat</th>
                <th>Nama Teknisi</th>
                <th>Jumlah Tugas Selesai</th>
            </tr>
        </thead>
        <tbody>
            @foreach($data as $index => $teknisi)
                <tr>
                    <td>{{ $index + 1 }}</td>
                    <td>{{ $teknisi->name }}</td>
                    <td>{{ $teknisi->tasks_count }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
