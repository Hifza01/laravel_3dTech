<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Task;
use App\Models\Company;
use App\Models\Category;
use App\Models\Customer1;
use App\Models\Customer2;
use App\Models\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class DashboardController extends Controller
{
    public function index() {
        $user = Auth::user();

        $currentDate = now();
        $currentMonth = now()->month;
        $currentYear = now()->year;

        $teknisi = User::where('level', 'teknisi')->get();

        $toDoTasks = Task::where('status', 'to_do')
            ->where('is_approved', true)
            ->where('due', '>=', $currentDate)
            ->with(['teknisi', 'comments.user', 'company', 'customer', 'customer2'])
            ->get();

        $inProgressTasks = Task::where('status', 'in_progress')
            ->with(['teknisi', 'comments.user', 'company', 'customer', 'customer2'])
            ->get();

        $doneTasks = Task::where('status', 'done')
            ->whereMonth('due', $currentMonth)
            ->whereYear('due', $currentYear)
            ->with(['teknisi', 'comments.user', 'company', 'customer', 'customer2'])
            ->get();

        $overdueTasks = Task::where('status', 'to_do')
            ->where('is_approved', true)
            ->where('due', '<', $currentDate) 
            ->with(['teknisi', 'comments.user', 'company', 'customer', 'customer2'])
            ->get();

        $notifications = Notification::latest()->get();

        $companies = Company::all();
        $categories = Category::all();
        $customers = Customer1::all();
        $customers2 = Customer2::all();

        return view('dashboard', compact('user', 'toDoTasks', 'overdueTasks', 'inProgressTasks', 'doneTasks', 'teknisi', 'notifications', 'companies', 'categories', 'customers', 'customers2'));
    }

    public function AddTask(Request $request)
    {
        $request->validate([
            'name' => 'required|exists:users,id',
            'category' => 'required|string', 
            'content' => 'required|string',
            'due' => 'required|date',
            'color' => 'required|string',
            'company' => 'required|in:3DTech,Ngx',
        ]);

        $category = Category::where('category_name', $request->category)->first();

        if (!$category) {
            return redirect('/dashboard')->with('fail', 'Kategori tidak valid');
        }

        try {
            $task = new Task;
            $task->teknisi_id = $request->name;
            $task->job_types = $request->job_types;
            $task->category = $request->category;  
            $task->no_category = $category->category_code;  
            $task->content = $request->content;
            $task->due = $request->due;
            $task->color = $request->color;
            $task->company = $request->company;
            $task->status = 'menunggu_disetujui'; 

            if ($request->has('customer_1') && $request->customer_1) {
                $task->customer_1_id = $request->customer_1;
            }
            if ($request->has('customer_2') && $request->customer_2) {
                $task->customer_2_id = $request->customer_2;
            }

            $task->save();

            return redirect('/dashboard')->with('success', 'Tugas Berhasil Ditambah');
        } catch (\Exception $e) {
            return redirect('/dashboard')->with('fail', 'Gagal menambah tugas: ' . $e->getMessage());
        }
    }

    public function loadEditForm($id) {
        $user = User::find($id);
        $teknisi = User::where('level', 'teknisi')->get();

        $notifications = Notification::latest()->get();

        return view('edit-user', compact('user', 'teknisi', 'notifications'));
    }

    public function EditUser(Request $request) {
        $request->validate([
            'name' => 'required|string',
            'email' => 'required|email',
            'password' => 'required|min:5|max:8',
        ]);

        try {
            User::where('id', $request->user_id)->update([
                'name' => $request->name,
                'email' => $request->email,
                'password' => Hash::make($request->password),
            ]);

            return redirect()->route('edit', $request->user_id)->with('success', 'Akun Berhasil Diedit');
        } catch (\Exception $e) {
            return redirect()->route('edit', $request->user_id)->with('fail', 'Akun Gagal Diedit');
        }
    }
}
